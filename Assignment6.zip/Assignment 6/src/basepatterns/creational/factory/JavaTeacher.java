package basepatterns.creational.factory;

public class JavaTeacher implements Teacher{
    @Override
    public void writeCode() {
        System.out.println("Java teacher teach OOP...");
    }
}
