package basepatterns.creational.factory;

public class JavaTeacherFactory implements TeacherFactory{
    @Override
    public Teacher createTeacher() {
        return new JavaTeacher();
    }
}
