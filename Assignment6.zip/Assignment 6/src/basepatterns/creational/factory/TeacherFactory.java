package basepatterns.creational.factory;


public interface TeacherFactory {
    Teacher createTeacher();
}
