package basepatterns.creational.factory;

public class Teachers {
    public static void main(String[] args){
        TeacherFactory teacherFactory = createTeacherFactoryBySpecialty("ict");
        Teacher teacher =  teacherFactory.createTeacher();

        teacher.writeCode();
    }

    static TeacherFactory createTeacherFactoryBySpecialty(String specialty){
        if(specialty.equalsIgnoreCase("java")) {
            return new JavaTeacherFactory();
        }else if(specialty.equalsIgnoreCase("ict")){
            return new ICTTeacherFactory();
        }else {
            throw new RuntimeException(specialty + " is unknown specialty.");
        }
    }
}
