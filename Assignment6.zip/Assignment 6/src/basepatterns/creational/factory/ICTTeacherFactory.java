package basepatterns.creational.factory;

public class ICTTeacherFactory implements TeacherFactory{
    @Override
    public Teacher createTeacher() {
        return new ICTTeacher();
    }
}
