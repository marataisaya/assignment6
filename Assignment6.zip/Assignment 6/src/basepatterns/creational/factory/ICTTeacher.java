package basepatterns.creational.factory;

public class ICTTeacher implements Teacher{
    @Override
    public void writeCode() {
        System.out.println("ICT teacher teach Information Communication Systems...");
    }
}
