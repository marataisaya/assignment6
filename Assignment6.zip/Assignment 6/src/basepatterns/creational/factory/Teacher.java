package basepatterns.creational.factory;

public interface Teacher {
    void writeCode();
}
