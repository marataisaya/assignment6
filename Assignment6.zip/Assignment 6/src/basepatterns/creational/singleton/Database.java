package basepatterns.creational.singleton;
//guarantees that the class will have only one single instance and will be given a global access point
public class Database {
    //    the field for storing the singleton  instance should be declared static
//The singleton's constructor should always be private to prevent direct construction calls with the `new` operator.
    private static Database database;//instance
    private static String logFile = "This is log file. \n\n";
    //synchronized used to block access to a method if another thread is already using it
    public static synchronized Database getDatabase(){//returns an instance Database
        if(database == null){
            database= new Database();
        }
        return database;
    }
    private Database(){

    };

    public void addLogInfo(String logInfo){//information that we want to enter in the log file
        logFile += logInfo+"\n";
    }
    public void showLogFile(){//will cout our Strings
        System.out.println(logFile);
    }


}
