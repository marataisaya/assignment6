package basepatterns.creational.singleton;


public class Application {
    public static void main(String[] args) {
        Database.getDatabase().addLogInfo("First log...");
        Database.getDatabase().addLogInfo("Second log...");
        Database.getDatabase().addLogInfo("Third log...");

        Database.getDatabase().showLogFile();
    }
}
