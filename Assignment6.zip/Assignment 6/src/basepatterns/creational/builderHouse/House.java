package basepatterns.creational.builderHouse;

public class House {
    private String stepA;
    private String stepB;
    private String stepZ;

    public void setStepZ(String stepZ) {
        this.stepZ = stepZ;
    }

    public void setStepB(String stepB) {
        this.stepB = stepB;
    }

    public void setStepA(String stepA) {
        this.stepA = stepA;
    }

    @Override
    public String toString() {
        return "House{" +
                "stepA='" + stepA + '\'' +
                ", stepB='" + stepB + '\'' +
                ", stepZ='" + stepZ + '\'' +
                '}';
    }
}
