package basepatterns.creational.builderHouse;

public class Product2 extends HouseBuilder{

    @Override
    void buildStepA() {
        house.setStepA("Build house garage");
    }

    @Override
    void buildStepB() {
        house.setStepB("Build house swimming pool");
    }

    @Override
    void buildStepZ() {
        house.setStepZ("Build house garden");
    }

}
