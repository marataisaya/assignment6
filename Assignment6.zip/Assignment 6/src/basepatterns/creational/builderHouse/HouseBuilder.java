package basepatterns.creational.builderHouse;

public class HouseBuilder {
    House house;

    void createHouse(){
        house = new House();
    }
    void buildStepA(){};
    void buildStepB(){};
    void buildStepZ(){};

    House getHouse(){
        return house;
    }
}
