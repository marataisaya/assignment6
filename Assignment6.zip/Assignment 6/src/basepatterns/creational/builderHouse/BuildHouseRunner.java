package basepatterns.creational.builderHouse;

public class BuildHouseRunner {
    public static void main(String[] args) {
        Director director = new Director();

        director.setBuilder(new Product1());
        House house = director.buildHouse();
        System.out.println(house);

        director.setBuilder(new Product2());

        House houseAdditions = director.buildHouse();
        System.out.println(houseAdditions);
    }
}
