package basepatterns.creational.builderHouse;

public class Product1 extends HouseBuilder{

    @Override
    void buildStepA() {
        house.setStepA("Build house walls");
    }

    @Override
    void buildStepB() {
        house.setStepB("Build house doors");
    }

    @Override
    void buildStepZ() {
        house.setStepZ("Build house roof");
    }

}
