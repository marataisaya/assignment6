package basepatterns.creational.builderHouse;

public class Director {
    HouseBuilder builder;

    public void setBuilder(HouseBuilder builder) {
        this.builder = builder;
    }
    House buildHouse(){
        builder.createHouse();
        builder.buildStepA();
        builder.buildStepB();
        builder.buildStepZ();

        House house = builder.getHouse();
        return house;
    }
}
