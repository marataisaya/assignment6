package basepatterns;

public class a {
}
